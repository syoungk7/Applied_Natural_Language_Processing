class Split_test():
    def __init__(self):
        
        ## Length after 80/20 split for clickbait data.
        self.x_train_len = 19200
        self.x_test_len = 4800
        
        ## Length after 80/20 split for wos data.
        self.x_train_wos_len = 1600
        self.x_test_wos_len = 400