import numpy as np

class Regression_Test():
	def __init__(self):

		# Sample input: 
		self.input1 = np.zeros((5,1))
		

		# Sample outputs:
		self.output1 = np.zeros((5,1))