import numpy as np
from torch import Tensor
import torch

class NN_Test():
	def __init__(self):

		# Sample outputs:
		self.sample_output = torch.tensor([[-0.0586,  0.0419, -0.0114,  0.0283],
									        [-0.0647,  0.0613, -0.0149,  0.0148],
									        [-0.0709,  0.0569, -0.0058,  0.0226]])

		